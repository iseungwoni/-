// node test/run.js  — 메모리 저장소로 fixture 전이와 live 경로를 검증합니다.
process.env.T04_MEMORY = '1';
const assert = require('assert');
const L = require('../api/_lib');
const seq = async ids => { await L.resetDemo(); for (const i of ids) await L.runFixture(i); return L.getState(L.DEMO); };
const chk = (s, f, e, rc, v, d) => { assert.deepStrictEqual([s.status.freshness, s.status.error_code, s.row_count, s.current.normalized_value, s.delta], [f, e, rc, v, d]); };
(async () => {
  chk(await seq(['T04-NORMAL-D1-A']), 'fresh', 'none', 1, 100, null);
  chk(await seq(['T04-NORMAL-D1-A', 'T04-NORMAL-D1-B']), 'fresh', 'none', 1, 105, null);
  chk(await seq(['T04-NORMAL-D1-A', 'T04-NORMAL-D1-B', 'T04-NORMAL-D2']), 'fresh', 'none', 2, 120, 15);
  const base = ['T04-NORMAL-D1-A', 'T04-NORMAL-D1-B'];
  for (const [id, code] of [['T04-TIMEOUT', 'timeout'], ['T04-AUTH-401', 'auth'], ['T04-RATE-429', 'rate_limit'], ['T04-OFFLINE', 'offline'], ['T04-SCHEMA-BREAK', 'schema_error']])
    chk(await seq([...base, id]), 'stale', code, 1, 105, null);
  chk(await seq([...base, 'T04-TIMEOUT', 'T04-RECOVER-D2']), 'fresh', 'none', 2, 120, 15);
  // 같은 날 3회 성공 → 1건, 다음 날 → 2건
  await L.resetDemo(); for (let i = 0; i < 3; i++) await L.runFixture('T04-NORMAL-D1-B');
  assert.strictEqual((await L.getState(L.DEMO)).row_count, 1);
  // live 경로(원천 응답을 흉내냄)
  const real = global.fetch, ok = t => ({ ok: true, status: 200, headers: { get: () => null }, json: async () => ({ current: { time: 1792480441, temperature_2m: t }, current_units: { temperature_2m: '°C' } }) });
  global.fetch = async () => ok(12.3); await L.liveRefresh();
  let s = await L.getState(L.LIVE); assert.deepStrictEqual([s.status.error_code, s.row_count, s.current.normalized_value, s.current.unit, s.current.record_date.length], ['none', 1, 12.3, '°C', 10]);
  global.fetch = async () => ({ ok: false, status: 429, headers: { get: () => '30' } }); await L.liveRefresh();
  s = await L.getState(L.LIVE); assert.deepStrictEqual([s.status.error_code, s.status.retry_after, s.row_count, s.current.normalized_value], ['rate_limit', 30, 1, 12.3]);
  global.fetch = async () => { const e = new Error('x'); e.name = 'AbortError'; throw e; }; await L.liveRefresh();
  assert.strictEqual((await L.getState(L.LIVE)).status.error_code, 'timeout');
  global.fetch = async () => ({ ok: true, status: 200, headers: { get: () => null }, json: async () => ({ current: {} }) }); await L.liveRefresh();
  s = await L.getState(L.LIVE); assert.deepStrictEqual([s.status.error_code, s.current.normalized_value], ['schema_error', 12.3]);
  global.fetch = real;
  console.log('ALL PASS');
})().catch(e => { console.error(e); process.exit(1); });
