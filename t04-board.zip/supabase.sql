-- Supabase SQL Editor에서 한 번 실행합니다.
create table if not exists t04_daily (
  signal_id        text not null,
  record_date      date not null,              -- Asia/Seoul 기준 날짜
  normalized_value double precision not null,
  unit             text not null,
  source_name      text not null,
  source_url       text not null,
  source_time      timestamptz,                -- 원천이 말하는 관측 시각
  fetched_at       timestamptz not null,       -- 내가 조회한 시각
  raw              jsonb,                      -- 원자료(대조용)
  primary key (signal_id, record_date)         -- 같은 날 1건 보장
);
create table if not exists t04_status (
  signal_id   text primary key,
  freshness   text not null check (freshness in ('fresh','stale')),
  error_code  text not null check (error_code in ('none','timeout','auth','rate_limit','offline','schema_error')),
  retry_after integer,
  updated_at  timestamptz not null default now()
);
-- 정책 없이 RLS만 켜면 공개(anon) 키로는 읽고 쓸 수 없고, 서버의 service key만 접근합니다.
alter table t04_daily  enable row level security;
alter table t04_status enable row level security;
