'use strict';
const { getState, runFixture, resetDemo, DEMO, FIXTURES } = require('./_lib');
// 합성 시험값 전용. 클라이언트는 fixture ID만 보내고 payload는 서버 파일에서만 읽습니다.
module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    if (req.method === 'POST') {
      const b = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
      if (b.action === 'reset') await resetDemo();
      else if (b.action === 'run' && FIXTURES[b.fixture]) await runFixture(b.fixture);
      else return res.status(400).json({ error: 'bad_request' });
    }
    res.status(200).json(await getState(DEMO));
  } catch (e) { res.status(500).json({ error: 'server_error' }); }
};
