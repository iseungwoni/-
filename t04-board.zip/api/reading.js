'use strict';
const { getState, liveRefresh, LIVE } = require('./_lib');
// GET: 저장된 상태 조회 / POST: 공개 원천을 새로 조회하고 저장(비밀키 없음)
module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    if (req.method === 'POST') await liveRefresh();
    res.status(200).json(await getState(LIVE));
  } catch (e) { res.status(500).json({ error: 'server_error' }); }
};
