'use strict';
// live 조회와 replay 재생이 같은 정규화·검증·저장 함수를 씁니다.
const KEYS = ['signal_id','normalized_value','unit','source_name','source_url','source_time','fetched_at','record_timezone','record_date'];
const ERRORS = ['timeout','auth','rate_limit','offline','schema_error'];
const LIVE = 'seoul-temperature-2m';
const DEMO = 'aleph-demo-index';
const SRC = 'https://api.open-meteo.com/v1/forecast?latitude=37.5665&longitude=126.978&current=temperature_2m&timezone=Asia%2FSeoul&timeformat=unixtime';
const DEADLINE_MS = 4000;

function kstDate(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) throw new TypeError('invalid date');
  const p = Object.fromEntries(new Intl.DateTimeFormat('en', { timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(d).map(x => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}

function validate(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) throw new TypeError('object required');
  if (Object.keys(r).sort().join() !== [...KEYS].sort().join()) throw new TypeError('keys mismatch');
  if (!/^[a-z0-9][a-z0-9._-]*$/.test(r.signal_id) || r.signal_id.length > 100) throw new TypeError('signal_id');
  if (typeof r.normalized_value !== 'number' || !Number.isFinite(r.normalized_value)) throw new TypeError('value');
  for (const f of ['unit', 'source_name']) if (typeof r[f] !== 'string' || !r[f].trim()) throw new TypeError(f);
  if (new URL(r.source_url).protocol !== 'https:') throw new TypeError('https');
  if (r.source_time !== null && Number.isNaN(new Date(r.source_time).getTime())) throw new TypeError('source_time');
  if (r.record_timezone !== 'Asia/Seoul') throw new TypeError('tz');
  if (r.record_date !== kstDate(r.fetched_at)) throw new TypeError('record_date');
}

// ---- 저장소: Supabase(REST, 서버 환경변수) 또는 테스트용 메모리 ----
const mem = { daily: [], status: {} };
const memStore = {
  async list(s) { return mem.daily.filter(r => r.signal_id === s).sort((a, b) => a.record_date.localeCompare(b.record_date)); },
  async upsert(row) { const i = mem.daily.findIndex(r => r.signal_id === row.signal_id && r.record_date === row.record_date); if (i >= 0) mem.daily[i] = row; else mem.daily.push(row); },
  async getStatus(s) { return mem.status[s] || null; },
  async setStatus(st) { mem.status[st.signal_id] = st; },
  async reset(s) { mem.daily = mem.daily.filter(r => r.signal_id !== s); delete mem.status[s]; }
};
async function sb(path, method, body, prefer) {
  const base = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_KEY;
  const r = await fetch(`${base}/rest/v1/${path}`, {
    method,
    headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', ...(prefer ? { Prefer: prefer } : {}) },
    body: body ? JSON.stringify(body) : undefined
  });
  if (!r.ok) throw new Error(`storage ${r.status}`);
  const t = await r.text();
  return t ? JSON.parse(t) : null;
}
const sbStore = {
  list: s => sb(`t04_daily?signal_id=eq.${encodeURIComponent(s)}&order=record_date.asc&select=*`, 'GET'),
  upsert: row => sb('t04_daily?on_conflict=signal_id,record_date', 'POST', row, 'resolution=merge-duplicates,return=minimal'),
  async getStatus(s) { const r = await sb(`t04_status?signal_id=eq.${encodeURIComponent(s)}&select=*`, 'GET'); return r[0] || null; },
  setStatus: st => sb('t04_status?on_conflict=signal_id', 'POST', st, 'resolution=merge-duplicates,return=minimal'),
  async reset(s) { await sb(`t04_daily?signal_id=eq.${encodeURIComponent(s)}`, 'DELETE'); await sb(`t04_status?signal_id=eq.${encodeURIComponent(s)}`, 'DELETE'); }
};
function store() {
  if (process.env.T04_MEMORY === '1') return memStore;
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_KEY) throw new Error('storage not configured');
  return sbStore;
}

// ---- 상태 전이 ----
async function applySuccess(reading, raw) {
  validate(reading);
  const row = { ...reading, raw };
  delete row.record_timezone; // 기준 시간대는 항상 Asia/Seoul로 고정이라 열을 두지 않음
  await store().upsert(row); // (signal_id, record_date) 기준 원자적 갱신
  await store().setStatus({ signal_id: reading.signal_id, freshness: 'fresh', error_code: 'none', retry_after: null, updated_at: new Date().toISOString() });
}
async function applyError(signal, code, retryAfter) {
  if (!ERRORS.includes(code)) throw new TypeError('error code');
  // 일별 기록은 건드리지 않고 상태만 stale로 바꿉니다(마지막 정상값 보존).
  await store().setStatus({ signal_id: signal, freshness: 'stale', error_code: code, retry_after: retryAfter ?? null, updated_at: new Date().toISOString() });
}
async function getState(signal) {
  const rows = await store().list(signal);
  const status = await store().getStatus(signal);
  const current = rows[rows.length - 1] || null;
  let delta = null;
  if (rows.length >= 2 && rows[rows.length - 2].unit === current.unit) {
    delta = Math.round((current.normalized_value - rows[rows.length - 2].normalized_value) * 100) / 100;
  }
  return { signal_id: signal, timezone: 'Asia/Seoul', current, status, delta, row_count: rows.length, rows };
}

// ---- live: 키 없는 공개 원천(Open-Meteo, 서울 현재 기온) ----
async function liveRefresh() {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), DEADLINE_MS);
  const fail = (code, ra) => applyError(LIVE, code, ra);
  try {
    let res;
    try { res = await fetch(SRC, { signal: ac.signal, headers: { accept: 'application/json' } }); }
    catch (e) { return fail(e && e.name === 'AbortError' ? 'timeout' : 'offline'); }
    if (res.status === 401 || res.status === 403) return fail('auth');
    if (res.status === 429) return fail('rate_limit', Number(res.headers.get('retry-after')) || null);
    if (!res.ok) return fail(res.status >= 500 ? 'offline' : 'schema_error');
    let j;
    try { j = await res.json(); }
    catch (e) { return fail(e && e.name === 'AbortError' ? 'timeout' : 'schema_error'); }
    const c = j && j.current, u = j && j.current_units;
    if (!c || typeof c.temperature_2m !== 'number' || typeof c.time !== 'number' || !u || typeof u.temperature_2m !== 'string') return fail('schema_error');
    const fetchedAt = new Date().toISOString();
    const reading = {
      signal_id: LIVE, normalized_value: c.temperature_2m, unit: u.temperature_2m,
      source_name: 'Open-Meteo (서울 현재 기온)', source_url: SRC,
      source_time: new Date(c.time * 1000).toISOString(), fetched_at: fetchedAt,
      record_timezone: 'Asia/Seoul', record_date: kstDate(fetchedAt)
    };
    try { await applySuccess(reading, { current: c, current_units: u }); }
    catch (e) { if (String(e.message).startsWith('storage')) throw e; return fail('schema_error'); }
  } finally { clearTimeout(timer); }
}

// ---- replay: 합성 fixture만 사용(DEMO signal에만 기록) ----
const FIXTURES = {
  'T04-NORMAL-D1-A': require('../fixtures/normal-d1-a.json'),
  'T04-NORMAL-D1-B': require('../fixtures/normal-d1-b.json'),
  'T04-NORMAL-D2': require('../fixtures/normal-d2.json'),
  'T04-TIMEOUT': require('../fixtures/timeout.json'),
  'T04-AUTH-401': require('../fixtures/auth-401.json'),
  'T04-RATE-429': require('../fixtures/rate-429.json'),
  'T04-OFFLINE': require('../fixtures/offline.json'),
  'T04-SCHEMA-BREAK': require('../fixtures/schema-break.json'),
  'T04-RECOVER-D2': require('../fixtures/recover-d2.json')
};
async function runFixture(id) {
  const fx = FIXTURES[id];
  if (!fx) throw new RangeError('unknown fixture');
  const t = fx.transport, ra = t.headers['retry-after'] ? Number(t.headers['retry-after']) : null;
  if (t.mode === 'timeout') return applyError(DEMO, 'timeout');
  if (t.mode === 'offline') return applyError(DEMO, 'offline');
  if (t.status === 401 || t.status === 403) return applyError(DEMO, 'auth');
  if (t.status === 429) return applyError(DEMO, 'rate_limit', ra);
  if (t.status >= 200 && t.status < 300) {
    try { validate(fx.payload); } catch { return applyError(DEMO, 'schema_error'); }
    return applySuccess(fx.payload, fx.payload);
  }
  return applyError(DEMO, 'schema_error');
}
async function resetDemo() { await store().reset(DEMO); }

module.exports = { LIVE, DEMO, FIXTURES, kstDate, validate, getState, liveRefresh, runFixture, resetDemo };
